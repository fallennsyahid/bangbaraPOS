<?php if (isset($component)) { $__componentOriginal239d102d1af5b71b775e4672900a02c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal239d102d1af5b71b775e4672900a02c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $attributes = $__attributesOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__attributesOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $component = $__componentOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__componentOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>

<body>
    <div x-data="setup()" x-init="$refs.loading.classList.add('hidden');
    setColors(color);" :class="{ 'dark': isDark }">
        <div class="flex h-screen antialiased text-gray-950 bg-prime dark:text-light">
            <!-- Loading screen -->
            <div x-ref="loading"
                class="fixed inset-0 z-50 flex items-center justify-center text-2xl font-semibold text-amber-300 bg-slate-950">
                Loading.....
            </div>

            <?php if (isset($component)) { $__componentOriginaldd6f566f8717597616167a2635c4418f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd6f566f8717597616167a2635c4418f = $attributes; } ?>
<?php $component = App\View\Components\Staff\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Staff\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $attributes = $__attributesOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__attributesOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $component = $__componentOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__componentOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>

            <div class="flex-1 h-full overflow-x-hidden overflow-y-auto">
                <?php if (isset($component)) { $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $attributes = $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $component = $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>

                <!-- Main content -->
                <main class="bg-prime">
                    <!-- Content header -->
                    <div class="flex items-center justify-between px-4 py-4 border-b lg:py-6">
                        <h1 class="text-xs md:text-lg space-x-2 text-zinc-950 font-serif">"Selamat datang di Dashboard
                            Staff!
                            Semoga harimu
                            produktif dan penuh energi, <?php echo e(Auth::user()->name); ?> 👋!"</h1>
                        <?php if (isset($component)) { $__componentOriginalcccfa1c62aca74a746a9b9d0fc8aab38 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcccfa1c62aca74a746a9b9d0fc8aab38 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.waButton','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.waButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcccfa1c62aca74a746a9b9d0fc8aab38)): ?>
<?php $attributes = $__attributesOriginalcccfa1c62aca74a746a9b9d0fc8aab38; ?>
<?php unset($__attributesOriginalcccfa1c62aca74a746a9b9d0fc8aab38); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcccfa1c62aca74a746a9b9d0fc8aab38)): ?>
<?php $component = $__componentOriginalcccfa1c62aca74a746a9b9d0fc8aab38; ?>
<?php unset($__componentOriginalcccfa1c62aca74a746a9b9d0fc8aab38); ?>
<?php endif; ?>
                    </div>

                    <!-- Content -->
                    <div class="mt-2">
                        <!-- State cards -->
                        <div class="grid grid-cols-1 gap-8 p-4 lg:grid-cols-2 xl:grid-cols-3">
                            <!-- Income card -->
                            <div class="bg-red-600 text-center text-white rounded-xl shadow-lg p-6 w-80 mx-auto">
                                <h6 class="text-lg font-medium">Total Income</h6>
                                <div class="flex gap-4 justify-center items-center">
                                    <img src="<?php echo e(asset('asset-admin/public/img/money-bag.png')); ?>" alt="Money Bag"
                                        width="50px" class="filter invert text-white">
                                    <p class="text-3xl font-bold">Rp <?php echo e(number_format($totalIncome)); ?></p>
                                </div>
                            </div>


                            <!-- Selling card -->
                            <div class="bg-red-600 text-center text-white rounded-xl shadow-lg p-6 w-80 mx-auto">
                                <h6 class="text-lg font-medium">Total Selling</h6>
                                <div class="flex gap-4 justify-center items-center">
                                    <img src="<?php echo e(asset('asset-admin/public/img/selling-bag.svg')); ?>" alt="50px">
                                    <p class="text-3xl font-bold"><?php echo e($histories); ?></p>
                                </div>
                            </div>

                            <!-- Orders card -->
                            <div class="bg-red-600 text-center text-white rounded-xl shadow-lg p-6 w-80 mx-auto">
                                <h6 class="text-lg font-medium">Total Orders</h6>
                                <div class="flex gap-4 justify-center items-center">
                                    <img src="<?php echo e(asset('asset-admin/public/img/orders.svg')); ?>" alt="Orders">
                                    <p class="text-3xl font-bold" id="totalOrders"><?php echo e($total_orders); ?></p>
                                </div>
                            </div>

                            <!-- Completed card -->
                            <div class="bg-red-600 text-center text-white rounded-xl shadow-lg p-6 w-80 mx-auto">
                                <h6 class="text-lg font-medium">Total completed orders</h6>
                                <div class="flex gap-4 justify-center items-center">
                                    <img src="<?php echo e(asset('asset-admin/public/img/completed-orders.svg')); ?>"
                                        alt="Completed Orders">
                                    <p class="text-3xl font-bold"><?php echo e($total_orders_completed); ?></p>
                                </div>
                            </div>

                            <!-- Cancelled card -->
                            <div class="bg-red-600 text-center text-white rounded-xl shadow-lg p-6 w-80 mx-auto">
                                <h6 class="text-lg font-medium">Total cancelled orders</h6>
                                <div class="flex gap-4 justify-center items-center">
                                    <img src="<?php echo e(asset('asset-admin/public/img/canceled-orders.svg')); ?>"
                                        alt="Canceled Orders">
                                    <p class="text-3xl font-bold"><?php echo e($total_orders_cancelled); ?></p>
                                </div>
                            </div>
                            <!-- Tickets card -->
                            
                        </div>



                        <!-- Charts -->
                        <div class="grid grid-cols-1 gap-4 p-4 lg:grid-cols-2 lg:gap-4 h-100">
                            <!-- Bar chart card (Total Income) -->
                            <div class="bg-[#D3D3D3] rounded-md border border-gray-400 shadow-xl p-4">
                                <!-- Card header -->
                                <div class="border-b border-white pb-2 mb-4">
                                    <h4 class="text-lg font-semibold text-gray-900">Orders Method (Today)</h4>
                                </div>

                                <!-- Chart -->
                                <div class="relative h-60">
                                    <canvas id="hourlyMethodChart"></canvas>
                                </div>
                            </div>

                            <!-- Best Seller Chart -->
                            <div class="bg-[#D3D3D3] rounded-md border border-gray-400 shadow-xl p-4">
                                <!-- Card header -->
                                <div class="border-b border-gray-400 pb-2 mb-4">
                                    <h4 class="text-lg font-semibold text-gray-900">Best Seller (Today)</h4>
                                </div>

                                <!-- Chart -->
                                <div class="relative h-60">
                                    <canvas id="bestSellerChart"></canvas>
                                    <div id="noDataMessage"
                                        class="flex items-center justify-center h-full text-gray-700 font-medium">
                                        Tidak ada produk yang dijual di hari ini.
                                    </div>
                                </div>
                            </div>
                        </div>





                </main>
            </div>

            <?php if (isset($component)) { $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel-content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $attributes = $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $component = $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
        </div>
    </div>

    <!-- All javascript code in this project for now is just for demo DON'T RELY ON IT  -->
    <?php if (isset($component)) { $__componentOriginal2910d975885782c1e8edd2261057a508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2910d975885782c1e8edd2261057a508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $attributes = $__attributesOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__attributesOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $component = $__componentOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__componentOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
    <script>
        function fetchOrders() {
            fetch('/get-total-orders-today')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('totalOrders').innerText = data.total_orders;
                })
                .catch(error => console.error('Error:', error));
        }

        setInterval(fetchOrders, 5000);
    </script>
    

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const ctxBestSeller = document.getElementById('bestSellerChart').getContext('2d');
            const noDataMessage = document.getElementById('noDataMessage');
            let bestSellerChart; // Simpan instance chart agar bisa diperbarui

            function fetchData() {
                let url = `/best-seller-today`; // Fetch langsung dari route ini

                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        // Jika sudah ada chart sebelumnya, hancurkan terlebih dahulu
                        if (bestSellerChart) {
                            bestSellerChart.destroy();
                        }

                        // Jika tidak ada produk, tampilkan pesan
                        if (!data.products || data.products.length === 0) {
                            document.getElementById('bestSellerChart').classList.add('hidden');
                            noDataMessage.classList.remove('hidden');
                        } else {
                            document.getElementById('bestSellerChart').classList.remove('hidden');
                            noDataMessage.classList.add('hidden');

                            bestSellerChart = new Chart(ctxBestSeller, {
                                type: 'doughnut',
                                data: {
                                    labels: data.products,
                                    datasets: [{
                                        label: 'Total Sold',
                                        data: data.totals,
                                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56',
                                            '#4BC0C0', '#9966FF'
                                        ],
                                        borderColor: '#FFFFFF',
                                        borderWidth: 2
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: {
                                        legend: {
                                            position: 'bottom'
                                        }
                                    }
                                }
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        document.getElementById('bestSellerChart').classList.add('hidden');
                        noDataMessage.textContent = 'Terjadi kesalahan saat mengambil data.';
                        noDataMessage.classList.remove('hidden');
                    });
            }

            // Fetch data langsung dari `/best-seller-today`
            fetchData();
        });
    </script>


    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const staticLabels = Array.from({
                length: 24
            }, (_, i) => (i < 10 ? '0' + i : i) + ':00');

            const ctxHourly = document.getElementById('hourlyMethodChart').getContext('2d');
            let hourlyChart = new Chart(ctxHourly, {
                type: 'line',
                data: {
                    labels: staticLabels,
                    datasets: [{
                            label: 'Tunai',
                            data: Array(24).fill(0),
                            backgroundColor: 'rgba(255, 206, 86, 0.2)',
                            borderColor: 'rgba(255, 206, 86, 1)',
                            borderWidth: 1,
                        },
                        {
                            label: 'nonTunai',
                            data: Array(24).fill(0),
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1,
                        },
                        {
                            label: 'Debit',
                            data: Array(24).fill(0),
                            backgroundColor: 'rgba(153, 102, 255, 0.2)', // biar beda warna dari nonTunai
                            borderColor: 'rgba(153, 102, 255, 1)',
                            borderWidth: 1,
                        }
                    ]
                },
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value.toLocaleString();
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });

            function updateHourlyChart() {
                fetch(`/hourly-orders-stats`)
                    .then(response => response.json())
                    .then(result => {
                        hourlyChart.data.labels = result.labels;
                        hourlyChart.data.datasets[0].data = result.tunai;
                        hourlyChart.data.datasets[1].data = result.non_tunai;
                        hourlyChart.data.datasets[2].data = result.debit;
                        hourlyChart.update();
                    })
                    .catch(error => console.error('Error fetching hourly stats:', error));
            }

            updateHourlyChart(); // langsung update saat halaman dimuat
        });
    </script>

</body>

</html>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>