<form action="<?php echo e(route('store.toggleStatus')); ?>" method="POST" id="status-form">
    <?php echo csrf_field(); ?>
    <p class="p-1 font-semibold text-black">Change Status:</p>
    <button onclick="event.preventDefault(); confirmChange()"
        class="<?php echo e(\App\Models\Store::first()->status == 1 ? 'bg-red-700 hover:bg-red-800' : 'bg-green-500 hover:bg-green-600'); ?> rounded-lg text-white px-4 py-2 transition-all ease-in-out duration-300">
        <?php echo e(optional(\App\Models\Store::first())->status ? 'Close Store' : 'Open Store'); ?>

    </button>
</form>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmChange() {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You will change the store status and customer access.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#b91c1c',
            cancelButtonColor: '#facc15',
            confirmButtonText: 'Yes, change',
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('status-form').submit();
            }
        });
    }
</script>

<script>
    <?php if(session('success')): ?>
        Swal.fire({
            position: "center",
            icon: "success",
            title: "Successfully change status",
            showConfirmButton: false,
            timer: 1500
        });
    <?php endif; ?>
</script>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/components/admin/waButton.blade.php ENDPATH**/ ?>