<a href="https://wa.me//+62895355285704" target="_blank"
    class="px-4 py-2 text-sm flex text-white rounded-md bg-amber-300 dark:bg-red-700 hover:bg-amber-400 hover:dark:bg-red-800 focus:outline-none focus:ring focus:ring-primary focus:ring-offset-1 focus:ring-offset-white dark:focus:ring-offset-dark">
    Need a Help? <span><img src="<?php echo e(asset('asset-view/assets/svg/wa.svg')); ?>" alt="" class="w-5 h-5 ml-2"></span>
</a>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/components/staff/waButton.blade.php ENDPATH**/ ?>