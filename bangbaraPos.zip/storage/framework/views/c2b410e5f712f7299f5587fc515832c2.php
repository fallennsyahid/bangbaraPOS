    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                title: "Success",
                icon: "success",
                text: "<?php echo e(session('success')); ?>",
                draggable: true,
                showConfirmButton: true,
                confirmButtonText: 'OK',
                customClass: {
                    confirmButton: 'confirm-button'
                }
            });
        <?php endif; ?>
    </script>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/components/admin/success-alert.blade.php ENDPATH**/ ?>