<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

<script>
    // document.addEventListener("DOMContentLoaded", function() {
    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: <?php echo json_encode(session('success'), 15, 512) ?>,
            showConfirmButton: false,
            timer: 1500,
        });
    <?php endif; ?>

    <?php if(session('checkout_success')): ?>
        Swal.fire({
            title: "Yeay! Pesananmu sudah terkirim",
            text: <?php echo json_encode(session('checkout_success'), 15, 512) ?>,
            icon: "success",
            confirmButtonText: "OK",
            confirmButtonColor: "#CC0000"
        });
    <?php endif; ?>

    if (localStorage.getItem("midtrans_payment_success") === "true") {
        Swal.fire({
            title: 'Berhasil!',
            text: 'Pembayaran kamu berhasil!',
            icon: 'success',
            timer: 1500,
            showConfirmButton: false,
        });

        // Hapus flag agar tidak muncul terus
        localStorage.removeItem("midtrans_payment_success");
    }

    // <?php if(session('checkout_success') === 'tunai'): ?>
    //     Swal.fire({
    //         title: "Yeay! Pesananmu sudah terkirim",
    //         text: "Pesanan berhasil dibuat, silakan menuju kasir untuk pembayaran",
    //         icon: "success",
    //         confirmButtonText: "OK",
    //         confirmButtonColor: "#CC0000"
    //     });
    // <?php elseif(session('checkout_success') === 'nonTunai'): ?>
    //     Swal.fire({
    //         title: "Yeay! Pesananmu sudah terkirim",
    //         text: "Chef kita lagi semangat masak buat kamu. Tunggu bentar lagi ya~",
    //         icon: "success",
    //         confirmButtonText: "OK",
    //         confirmButtonColor: "#CC0000"
    //     });
    // <?php endif; ?>
    // });
</script>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/components/sweet-alert.blade.php ENDPATH**/ ?>