<?php if (isset($component)) { $__componentOriginal239d102d1af5b71b775e4672900a02c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal239d102d1af5b71b775e4672900a02c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $attributes = $__attributesOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__attributesOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $component = $__componentOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__componentOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>

<body>
    <div x-data="setup()" x-init="$refs.loading.classList.add('hidden');
    setColors(color);" :class="{ 'dark': isDark }">
        <div class="flex h-screen antialiased text-gray-950 bg-prime dark:text-light">
            <!-- Loading screen -->
            <div x-ref="loading"
                class="fixed inset-0 z-50 flex items-center justify-center text-2xl font-semibold text-amber-300 bg-slate-950">
                Loading.....
            </div>

            <?php if (isset($component)) { $__componentOriginaldd6f566f8717597616167a2635c4418f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd6f566f8717597616167a2635c4418f = $attributes; } ?>
<?php $component = App\View\Components\Staff\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Staff\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $attributes = $__attributesOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__attributesOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $component = $__componentOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__componentOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>

            <div class="flex-1 h-full overflow-x-hidden overflow-y-auto">
                <?php if (isset($component)) { $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $attributes = $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $component = $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>

                <!-- Main content -->
                <main class="bg-prime">
                    <!-- Content header -->
                    <div class="flex items-center justify-between px-4 py-2 border-b lg:py-4">
                        <h1 class="text-2xl font-semibold text-zinc-950">Order Details</h1>
                    </div>


                    <!-- Content -->
                    <div class="flex flex-col items-center justify-center min-h-full bg-prime px-4 py-4">
                        <!-- Navigasi -->
                        <h2 class="mb-4">
                            <a href="<?php echo e(route('staffOrders.index')); ?>" class="text-amber-400 hover:underline">Back</a> /
                            <a href="/staff/dashboard" class="hover:underline text-zinc-950">Home</a>
                        </h2>

                        <!-- Kontainer Tabel -->
                        <div id="printArea" class="w-full max-w-6xl bg-white shadow-lg rounded-lg p-6">
                            <!-- Detail Pemesan -->
                            <div class="mb-4">
                                <label class="block text-gray-700 font-semibold">Nama Pemesan:</label>
                                <input type="text" value="<?php echo e($order->customer_name); ?>"
                                    class="w-full p-2 border rounded-md bg-gray-100 text-zinc-900" readonly>
                            </div>

                            <!-- Detail Kasir -->
                            <div class="mb-4">
                                <label class="block text-gray-700 font-semibold">Nama Kasir:</label>
                                <input type="text" value="<?php echo e($order->casier_name); ?>"
                                    class="w-full p-2 border rounded-md bg-gray-100 text-zinc-900" readonly>
                            </div>

                            <!-- Tabel Pesanan -->
                            <div class="overflow-x-auto shadow-md">
                                <table class="table-auto border-collapse w-full text-left shadow-md rounded-md">
                                    <tbody class="bg-gray-50">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="hover:bg-gray-200">
                                                <td class="px-6 py-4 text-sm text-gray-900">#<?php echo e($order->id); ?></td>
                                                <td class="px-6 py-4 text-sm">
                                                    <img src="<?php echo e(Storage::url($product['gambar_menu'])); ?>"
                                                        class="w-20 h-20 object-cover rounded-md" alt="Gambar Product">
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-900">
                                                    <?php echo e($product['nama_menu']); ?>

                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-900">
                                                    Rp<?php echo e(number_format($product['price'], 0, ',', '.')); ?>

                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($product['quantity']); ?>X
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Total Price -->
                            <div class="mt-4">
                                <label class="block text-gray-700 font-semibold">Total:</label>
                                <textarea class="w-full p-2 border rounded-md bg-gray-100 text-zinc-950" readonly>Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></textarea>
                            </div>

                            <!-- Catatan -->
                            <div class="mt-4">
                                <label class="block text-gray-700 font-semibold">Catatan:</label>
                                <textarea class="w-full p-2 border rounded-md bg-gray-100 text-zinc-950" readonly><?php echo e($order->request); ?></textarea>
                            </div>

                            <!-- Metode Pembayaran -->
                            <div class="mt-4">
                                <label class="block text-gray-700 font-semibold">Metode Pembayaran:</label>
                                <input type="text" value="<?php echo e($order->payment_method); ?>"
                                    class="w-full p-2 border rounded-md bg-gray-100 text-zinc-950" readonly>
                            </div>

                            <!-- Opsi Layanan -->
                            <div class="mt-4">
                                <label class="block text-gray-700 font-semibold">Layanan:</label>
                                <input type="text" value="<?php echo e($order->serve_option); ?>"
                                    class="w-full p-2 border rounded-md bg-gray-100 text-zinc-950" readonly>
                            </div>

                            <div class="mt-4">
                                <label class="block text-gray-700 font-semibold">Phone Number:</label>
                                <a href="https://wa.me/<?php echo e($order->customer_phone); ?>" target="_blank">
                                    <input type="text" value="<?php echo e($order->customer_phone); ?>"
                                        class="w-full p-2 border rounded-md bg-gray-100 text-zinc-950 cursor-pointer"
                                        readonly>
                                </a>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

            <?php if (isset($component)) { $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel-content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $attributes = $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $component = $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
        </div>
    </div>

    <!-- All javascript code in this project for now is just for demo DON'T RELY ON IT  -->
    <?php if (isset($component)) { $__componentOriginal2910d975885782c1e8edd2261057a508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2910d975885782c1e8edd2261057a508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $attributes = $__attributesOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__attributesOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $component = $__componentOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__componentOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
    

    <script>
        document.getElementById('printButton').addEventListener('click', function(event) {
            event.preventDefault();

            // Hide web display
            document.getElementById('printArea').classList.add('hidden');
            document.getElementById('printDisplay').classList.remove('hidden')

            // Print
            window.print();

            // return web display
            document.getElementById('printArea').classList.remove('hidden');
            document.getElementById('printDisplay').classList.add('hidden');
        });
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/staff/staffOrders/show.blade.php ENDPATH**/ ?>