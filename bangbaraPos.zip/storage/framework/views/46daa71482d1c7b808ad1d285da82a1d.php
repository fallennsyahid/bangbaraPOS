<?php if (isset($component)) { $__componentOriginal239d102d1af5b71b775e4672900a02c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal239d102d1af5b71b775e4672900a02c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $attributes = $__attributesOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__attributesOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal239d102d1af5b71b775e4672900a02c6)): ?>
<?php $component = $__componentOriginal239d102d1af5b71b775e4672900a02c6; ?>
<?php unset($__componentOriginal239d102d1af5b71b775e4672900a02c6); ?>
<?php endif; ?>

<body>
    <div x-data="setup()" x-init="$refs.loading.classList.add('hidden');
    setColors(color);" :class="{ 'dark': isDark }">
        <div class="flex h-screen antialiased text-gray-950 bg-gray-100 dark:bg-dark dark:text-light">
            <!-- Loading screen -->
            <div x-ref="loading"
                class="fixed inset-0 z-50 flex items-center justify-center text-2xl font-semibold text-amber-300 bg-slate-950">
                Loading.....
            </div>

            <?php if (isset($component)) { $__componentOriginaldd6f566f8717597616167a2635c4418f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd6f566f8717597616167a2635c4418f = $attributes; } ?>
<?php $component = App\View\Components\Staff\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Staff\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $attributes = $__attributesOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__attributesOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd6f566f8717597616167a2635c4418f)): ?>
<?php $component = $__componentOriginaldd6f566f8717597616167a2635c4418f; ?>
<?php unset($__componentOriginaldd6f566f8717597616167a2635c4418f); ?>
<?php endif; ?>

            <div class="flex-1 h-full overflow-x-hidden overflow-y-auto">
                <?php if (isset($component)) { $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.staff.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('staff.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $attributes = $__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__attributesOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0)): ?>
<?php $component = $__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0; ?>
<?php unset($__componentOriginal7bbf92dfe8841cd60c3bb94a249f5aa0); ?>
<?php endif; ?>

                <!-- Main content -->
                <main class="bg-gray-100 p-6">
                    <!-- Content header -->
                    <div class="flex items-center justify-between px-4 py-2 border-b lg:py-4">
                        <h1 class="text-2xl font-semibold text-zinc-950">Settings</h1>
                    </div>
                    <h2 class="mb-4 text-center">
                        <a href="javascript:history.back()" class="text-amber-400 hover:underline">Back </a>/
                        <a href="/staff/dashboard" class="hover:underline text-zinc-950">Home</a>
                    </h2>
                    <div class="min-h-screen mt-4 items-center justify-center bg-gray-100">
                        
                        <h1 class="text-xl text-center font-semibold text-zinc-950 mb-4">Printer Settings</h1>
                        <div class="min-h-full mt-4 flex items-center justify-center bg-prime">
                            <div class=" w-full mx-auto bg-white p-6 rounded-lg shadow-lg">
                                <div class="flex flex-col items-center">
                                    <p><strong>Current:</strong> <?php echo e($user->printer_name ?? 'Not Set yet'); ?></p>
                                    <form action="<?php echo e(route('staff.setPrinter')); ?>" method="POST"
                                        class="flex flex-col items-center w-full">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" placeholder="Set Printer Name" name="printer_name"
                                            id="printe_name"
                                            class="p-2 rounded-xl font-medium w-full border-2 border-yellow-300 text-center focus:outline-none focus:border-2 focus:border-yellow-400 focus:shadow-lg">
                                        <label for="printer-update"
                                            class="flex items-center justify-center gap-2 bg-yellow-400 py-2 px-4 mt-4 max-w-40 rounded-md text-white font-semibold cursor-pointer hover:bg-yellow-500 group">
                                            <svg fill="#000000" width="30px" height="30px" viewBox="0 0 24 24"
                                                class="icon flat-line group-hover:rotate-180 transition duration-300"
                                                id="update-alt" data-name="Flat Line"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                    stroke-linejoin="round"></g>
                                                <g id="SVGRepo_iconCarrier">
                                                    <path id="primary" d="M5.07,8A8,8,0,0,1,20,12"
                                                        style="fill: none; stroke: #ffffff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;">
                                                    </path>
                                                    <path id="primary-2" data-name="primary"
                                                        d="M18.93,16A8,8,0,0,1,4,12"
                                                        style="fill: none; stroke: #ffffff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;">
                                                    </path>
                                                    <polyline id="primary-3" data-name="primary" points="5 3 5 8 10 8"
                                                        style="fill: none; stroke: #ffffff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;">
                                                    </polyline>
                                                    <polyline id="primary-4" data-name="primary"
                                                        points="19 21 19 16 14 16"
                                                        style="fill: none; stroke: #ffffff; stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;">
                                                    </polyline>
                                                </g>
                                            </svg>
                                            Update
                                        </label>
                                        <input type="submit" value="Update" class="hidden" id="printer-update">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </main>

                <!-- Main footer -->
                <footer
                    class="flex items-center justify-between p-2 bg-white dark:bg-zinc-900 dark:border-primary-darker">
                    <div>Bangbara &copy; 2025</div>
                    <div>
                        Made by
                        <a href="https://github.com/Kamona-WD" target="_blank"
                            class="text-blue-500 hover:underline">BangbaraPos</a>
                    </div>
                </footer>
            </div>

            <?php if (isset($component)) { $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel-content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $attributes = $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $component = $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal2910d975885782c1e8edd2261057a508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2910d975885782c1e8edd2261057a508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $attributes = $__attributesOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__attributesOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $component = $__componentOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__componentOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/staff/staffSettings/index.blade.php ENDPATH**/ ?>