<?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>

<body>
    <div x-data="setup()" x-init="$refs.loading.classList.add('hidden');
    setColors(color);" :class="{ 'dark': isDark }">
        <div class="flex h-screen antialiased text-gray-950 bg-prime dark:text-light">
            <!-- Loading screen -->
            <div x-ref="loading"
                class="fixed inset-0 z-50 flex items-center justify-center text-2xl font-semibold text-amber-300 bg-slate-950">
                Loading.....
            </div>

            <?php if (isset($component)) { $__componentOriginalbebe114f3ccde4b38d7462a3136be045 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbebe114f3ccde4b38d7462a3136be045 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $attributes = $__attributesOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $component = $__componentOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__componentOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>

            <div class="flex-1 h-full overflow-x-hidden overflow-y-auto">
                <?php if (isset($component)) { $__componentOriginalf818c67b6eb448edb731318e48f2e69b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf818c67b6eb448edb731318e48f2e69b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf818c67b6eb448edb731318e48f2e69b)): ?>
<?php $attributes = $__attributesOriginalf818c67b6eb448edb731318e48f2e69b; ?>
<?php unset($__attributesOriginalf818c67b6eb448edb731318e48f2e69b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf818c67b6eb448edb731318e48f2e69b)): ?>
<?php $component = $__componentOriginalf818c67b6eb448edb731318e48f2e69b; ?>
<?php unset($__componentOriginalf818c67b6eb448edb731318e48f2e69b); ?>
<?php endif; ?>

                <!-- Main content -->
                <main class="bg-prime">
                    <!-- Content header -->
                    <div class="flex items-center justify-between px-4 py-2 border-b lg:py-4">
                        <h1 class="text-2xl font-semibold text-zinc-950">Edit Product</h1>

                    </div>

                    <!-- Content -->
                    <div class="min-h-full mb-4 py-5 flex flex-col items-center justify-center bg-prime px-4">
                        <h2 class="mb-4"><a href="<?php echo e(route('products.index')); ?>"
                                class="text-amber-400 hover:underline">Back </a>/
                            <a href="/admin/dashboard" class="hover:underline text-zinc-900">Home</a>
                        </h2>
                        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST"
                            enctype="multipart/form-data"
                            class="w-full max-w-5xl bg-thead text-gray-900 p-6 rounded-lg shadow-lg">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <h2 class="text-2xl font-bold text-center mb-6 text-zinc-900">
                                Edit
                                Product</h2>

                            <!-- Input Nama Produk -->
                            <div class="mb-4">
                                <label for="name" class="block text-sm font-medium mb-2">Product Name</label>
                                <input type="text" id="nama_menu" name="nama_menu"
                                    value="<?php echo e(old('nama_menu', $product->nama_menu)); ?>"
                                    class="w-full px-4 py-2 text-gray-900 bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none"
                                    placeholder="Enter product name" required />
                            </div>

                            <!-- Input Deskripsi Produk -->
                            <div class="mb-4">
                                <label for="description" class="block text-sm font-medium mb-2">Product
                                    Description</label>
                                <textarea id="deskripsi_menu" name="deskripsi_menu" rows="4"
                                    value="<?php echo e(old('deskripsi_menu', $product->deskripsi_menu)); ?>"
                                    class="w-full px-4 py-2 text-gray-900 bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none"
                                    placeholder="Enter product description"><?php echo e(old('deskripsi_menu', $product->deskripsi_menu)); ?></textarea>
                            </div>

                            <!-- Input Harga -->
                            <div class="mb-4">
                                <label for="price" class="block text-sm font-medium mb-2">Price</label>
                                <input type="number" id="harga_menu" name="harga_menu" step="0.01"
                                    value="<?php echo e(old('harga_menu', $product->harga_menu)); ?>"
                                    class="w-full px-4 py-2 text-gray-900  bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none"
                                    placeholder="Enter product price" required />
                            </div>

                            <!-- Dropdown Kategori -->
                            <div class="mb-4">
                                <label for="category_id" class="block text-sm font-medium mb-2">Category</label>
                                <select id="category_id" name="category_id"
                                    class="w-full px-4 py-2 text-gray-900  bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none"
                                    required>
                                    <option value="">Select a Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                            <?php echo e(old('category_id', $product->category_id ?? '') == $category->id ? 'selected' : ''); ?>>
                                            <?php echo e($category->nama_kategori); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Input Gambar Produk (Opsional) -->
                            <div class="mb-4">
                                <label for="image" class="block text-sm font-medium mb-2">Product Image</label>

                                <!-- Pratinjau Gambar Lama -->
                                <?php if(!empty($product->gambar_menu)): ?>
                                    <div class="mb-2">
                                        <img src="<?php echo e(asset('storage/' . $product->gambar_menu)); ?>"
                                            alt="Current Product Image" class="w-32 h-32 object-cover rounded-md">
                                    </div>
                                <?php endif; ?>

                                <!-- Input File -->
                                <input type="file" id="gambar_menu" name="gambar_menu"
                                    class="w-full px-4 py-2 text-gray-900  bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none" />
                            </div>


                            <div class="mb-4">
                                <label for="status_produk" class="block text-sm font-medium mb-2">Product
                                    Status</label>
                                <select id="status_produk" name="status_produk"
                                    class="w-full px-4 py-2 text-gray-900  bg-yellow-50 border border-yellow-400 dark:border-yellow-500 rounded-md focus:ring-2 focus:ring-yellow-500 focus:outline-none">
                                    <option value="Active"
                                        <?php echo e(old('status_produk', $product->status_produk) === 'active' ? 'selected' : ''); ?>>
                                        Active
                                    </option>
                                    <option value="Non-active"
                                        <?php echo e(old('status_produk', $product->status_produk) === 'Non-active' ? 'selected' : ''); ?>>
                                        Non-active
                                    </option>
                                </select>
                            </div>


                            <!-- Tombol Submit -->
                            <button type="submit"
                                class="w-full bg-yellow-500 mt-5 text-white font-bold py-2 px-4 rounded-md hover:bg-yellow-600 dark:hover:bg-yellow-400 focus:ring-2 focus:ring-yellow-500 focus:outline-none">
                                Submit
                            </button>
                        </form>
                    </div>




                </main>
            </div>

            <?php if (isset($component)) { $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.panel-content','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.panel-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $attributes = $__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__attributesOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31)): ?>
<?php $component = $__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31; ?>
<?php unset($__componentOriginal5fd2809c10adcef48cb43eb6b43a7e31); ?>
<?php endif; ?>
        </div>
    </div>

    <!-- All javascript code in this project for now is just for demo DON'T RELY ON IT  -->
    <?php if (isset($component)) { $__componentOriginal2910d975885782c1e8edd2261057a508 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2910d975885782c1e8edd2261057a508 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $attributes = $__attributesOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__attributesOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2910d975885782c1e8edd2261057a508)): ?>
<?php $component = $__componentOriginal2910d975885782c1e8edd2261057a508; ?>
<?php unset($__componentOriginal2910d975885782c1e8edd2261057a508); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\laragon\www\bangbaraPos\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>