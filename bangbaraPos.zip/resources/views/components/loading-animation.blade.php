<div x-ref="loading" class="fixed inset-0 z-50 flex items-center justify-center h-full text-amber-300 bg-slate-950">
    <div class="w-20 h-20 border-[6px] border-solid border-[#ccc] border-t-[#3498db] rounded-full animation-round">
    </div>
</div>
